function buttonAction(){
    alert("Sorry! This is just a template design. You can't go anywhere elese through this link/button.")
}